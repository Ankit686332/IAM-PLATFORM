use serde::{Deserialize, Serialize};
use uuid::Uuid;
use validator::Validate;

#[derive(Debug, Deserialize, Validate)]
pub struct CreateMembershipRequest {
    pub user_id: Uuid,
    pub organization_id: Uuid,
}

#[derive(Debug, Serialize)]
pub struct MembershipResponse {
    pub message: String,
}
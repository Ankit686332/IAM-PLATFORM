use axum::{
    extract::{Path, State},
    Json,
};
use uuid::Uuid;
use validator::Validate;

use crate::{
    app_state::AppState,
    schemas::organization::{
        CreateOrganizationRequest,
        OrganizationResponse,
    },
    services::organization_service::OrganizationService,
};

pub async fn create(
    State(state): State<AppState>,
    Json(request): Json<CreateOrganizationRequest>,
) -> Json<OrganizationResponse> {
    request.validate().unwrap();

    OrganizationService::create(
        &state.db,
        request,
    )
    .await
    .unwrap();

    Json(OrganizationResponse {
        message: "Organization Created Successfully".to_string(),
    })
}

pub async fn get_all(
    State(state): State<AppState>,
) -> Json<Vec<crate::models::organization::Organization>> {
    let organizations = OrganizationService::get_all(&state.db)
        .await
        .unwrap();

    Json(organizations)
}

pub async fn get_by_id(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Json<Option<crate::models::organization::Organization>> {
    let organization = OrganizationService::get_by_id(&state.db, id)
        .await
        .unwrap();

    Json(organization)
}
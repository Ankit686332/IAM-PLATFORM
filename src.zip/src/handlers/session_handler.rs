use axum::{
    extract::{Extension, Path, State},
    Json,
};
use uuid::Uuid;

use crate::{
    app_state::AppState,
    schemas::auth::AuthResponse,
    schemas::session::SessionResponse,
    services::session_service::SessionService,
};

pub async fn get_sessions(
    State(state): State<AppState>,
    Extension(user_id): Extension<Uuid>,
) -> Json<Vec<SessionResponse>> {
    let sessions = SessionService::get_sessions(
        &state.db,
        user_id,
    )
    .await
    .unwrap();

    let response = sessions
        .into_iter()
        .map(|session| SessionResponse {
            id: session.id,
            user_id: session.user_id,
            created_at: session.created_at,
            expires_at: session.expires_at,
        })
        .collect();

    Json(response)
}

pub async fn delete_session(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Json<AuthResponse> {
    SessionService::delete_session(
        &state.db,
        id,
    )
    .await
    .unwrap();

    Json(AuthResponse {
        message: "Session revoked successfully".to_string(),
    })
}
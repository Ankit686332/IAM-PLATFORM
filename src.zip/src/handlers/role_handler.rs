use axum::{
    extract::{Path, State},
    Json,
};
use uuid::Uuid;
use validator::Validate;

use crate::{
    app_state::AppState,
    models::role::Role,
    schemas::role::{
        CreateRoleRequest,
        RoleResponse,
    },
    services::role_service::RoleService,
};

pub async fn create(
    State(state): State<AppState>,
    Json(request): Json<CreateRoleRequest>,
) -> Json<RoleResponse> {
    request.validate().unwrap();

    RoleService::create(&state.db, request)
        .await
        .unwrap();

    Json(RoleResponse {
        message: String::from("Role created successfully"),
    })
}

pub async fn get_all(
    State(state): State<AppState>,
) -> Json<Vec<Role>> {
    let roles = RoleService::get_all(&state.db)
        .await
        .unwrap();

    Json(roles)
}

pub async fn get_by_id(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Json<Option<Role>> {
    let role = RoleService::get_by_id(&state.db, id)
        .await
        .unwrap();

    Json(role)
}
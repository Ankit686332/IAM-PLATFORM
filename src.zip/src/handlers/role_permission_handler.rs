use axum::{
    extract::State,
    Json,
};

use crate::{
    app_state::AppState,
    schemas::role_permission::{
        AssignPermissionRequest,
        AssignPermissionResponse,
    },
    services::role_permission_service::RolePermissionService,
};

pub async fn assign(
    State(state): State<AppState>,
    Json(request): Json<AssignPermissionRequest>,
) -> Json<AssignPermissionResponse> {
    RolePermissionService::assign(&state.db, request)
        .await
        .unwrap();

    Json(AssignPermissionResponse {
        message: String::from("Permission assigned successfully"),
    })
}

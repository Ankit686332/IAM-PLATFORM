use axum::{
    extract::{Path, State},
    Json,
};
use uuid::Uuid;
use validator::Validate;

use crate::{
    app_state::AppState,
    models::permission::Permission,
    schemas::permission::{
        CreatePermissionRequest,
        PermissionResponse,
    },
    services::permission_service::PermissionService,
};

pub async fn create(
    State(state): State<AppState>,
    Json(request): Json<CreatePermissionRequest>,
) -> Json<PermissionResponse> {
    request.validate().unwrap();

    PermissionService::create(&state.db, request)
        .await
        .unwrap();

    Json(PermissionResponse {
        message: String::from("Permission created successfully"),
    })
}

pub async fn get_all(
    State(state): State<AppState>,
) -> Json<Vec<Permission>> {
    let permissions = PermissionService::get_all(&state.db)
        .await
        .unwrap();

    Json(permissions)
}

pub async fn get_by_id(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Json<Option<Permission>> {
    let permission = PermissionService::get_by_id(&state.db, id)
        .await
        .unwrap();

    Json(permission)
}
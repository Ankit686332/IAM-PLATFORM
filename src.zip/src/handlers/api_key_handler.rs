use axum::{
    extract::{Path, State},
    Json,
};
use uuid::Uuid;
use validator::Validate;

use crate::{
    app_state::AppState,
    schemas::api_key::{
        ApiKeyResponse,
        CreateApiKeyRequest,
        CreateApiKeyResponse,
    },
    schemas::auth::AuthResponse,
    services::{
        api_key_service::ApiKeyService,
        audit_log_service::AuditLogService,
    },
};

pub async fn create_api_key(
    State(state): State<AppState>,
    Json(request): Json<CreateApiKeyRequest>,
) -> Json<CreateApiKeyResponse> {
    request.validate().unwrap();

    let (api_key, raw_key) = ApiKeyService::create(
        &state.db,
        request.organization_id,
        request.name,
        request.description,
        request.scopes,
        request.expires_at,
    )
    .await
    .unwrap();

    AuditLogService::create(
        &state.db,
        None,
        Some(request.organization_id),
        "CREATE",
        "API_KEY",
        Some(api_key.id),
        Some("API Key created"),
        None,
    )
    .await
    .unwrap();

    Json(CreateApiKeyResponse { api_key: raw_key })
}

pub async fn list_api_keys(
    State(state): State<AppState>,
) -> Json<Vec<ApiKeyResponse>> {
    let keys = ApiKeyService::list(&state.db)
        .await
        .unwrap();

    Json(
        keys.into_iter()
            .map(|k| ApiKeyResponse {
                id: k.id,
                name: k.name,
                description: k.description,
                scopes: k.scopes,
                status: k.status,
                expires_at: k.expires_at,
            })
            .collect(),
    )
}

pub async fn delete_api_key(
    State(state): State<AppState>,
    Path(id): Path<Uuid>,
) -> Json<AuthResponse> {
    ApiKeyService::delete(&state.db, id)
        .await
        .unwrap();

    Json(AuthResponse {
        message: "API Key deleted successfully".to_string(),
    })
}
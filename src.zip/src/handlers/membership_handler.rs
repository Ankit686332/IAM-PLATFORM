use axum::{
    extract::State,
    Json,
};
use validator::Validate;

use crate::{
    app_state::AppState,
    schemas::membership::{
        CreateMembershipRequest,
        MembershipResponse,
    },
    services::membership_service::MembershipService,
};

pub async fn create(
    State(state): State<AppState>,
    Json(request): Json<CreateMembershipRequest>,
) -> Json<MembershipResponse> {
    request.validate().unwrap();

    MembershipService::create(&state.db, request)
        .await
        .unwrap();

    Json(MembershipResponse {
        message: "Membership Created Successfully".to_string(),
    })
}

use axum::{
    extract::State,
    Json,
};

use crate::{
    app_state::AppState,
    schemas::member_role::{
        AssignRoleRequest,
        AssignRoleResponse,
    },
    services::member_role_service::MemberRoleService,
};

pub async fn assign(
    State(state): State<AppState>,
    Json(request): Json<AssignRoleRequest>,
) -> Json<AssignRoleResponse> {
    MemberRoleService::assign(&state.db, request)
        .await
        .unwrap();

    Json(AssignRoleResponse {
        message: String::from("Role assigned successfully"),
    })
}

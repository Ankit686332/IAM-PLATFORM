mod app_state;
mod config;
mod errors;
mod handlers;
mod middleware;
mod models;
mod repositories;
mod routes;
mod schemas;
mod services;
mod utils;

use app_state::AppState;
use axum::{
    extract::State,
    routing::get,
    Router,
};
use config::{
    database,
    settings::Settings,
};

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let settings = Settings::new();

    let db = database::connect(&settings.database_url)
        .await
        .expect("Failed to connect to database");

    println!("Database Connected Successfully");

    let state = AppState { db };

    let app = Router::new()
        .route("/", get(home))
        .route("/health", get(health))
        .nest("/auth", routes::auth_routes::auth_routes())
        .nest("/users", routes::user_routes::user_routes())
        .nest("/organizations", routes::organization_routes::organization_routes())
        .nest("/memberships", routes::membership_routes::membership_routes())
        .nest("/roles", routes::role_routes::role_routes())
        .nest("/permissions", routes::permission_routes::permission_routes())
        .nest("/role-permissions", routes::role_permission_routes::role_permission_routes())
        .nest("/member-roles", routes::member_role_routes::member_role_routes())
        .nest("/sessions", routes::session_routes::session_routes())
        .nest("/api-keys", routes::api_key_routes::api_key_routes())
        .with_state(state);

    let address = format!("{}:{}", settings.host, settings.port);

    let listener = tokio::net::TcpListener::bind(&address)
        .await
        .expect("Failed to bind server");

    println!("Server running at http://{}", address);

    axum::serve(listener, app)
        .await
        .expect("Server failed");
}

async fn home() -> &'static str {
    "IAM Platform Backend is Running"
}

async fn health(
    State(state): State<AppState>,
) -> &'static str {
    let _ = &state.db;
    "Database Connected"
}
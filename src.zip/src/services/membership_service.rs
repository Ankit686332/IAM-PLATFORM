use sqlx::PgPool;

use crate::{
    repositories::membership_repository::MembershipRepository,
    schemas::membership::CreateMembershipRequest,
};

pub struct MembershipService;

impl MembershipService {
    pub async fn create(
        pool: &PgPool,
        request: CreateMembershipRequest,
    ) -> Result<(), sqlx::Error> {
        MembershipRepository::create(
            pool,
            request.user_id,
            request.organization_id,
        )
        .await
    }
}

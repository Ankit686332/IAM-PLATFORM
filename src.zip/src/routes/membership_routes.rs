use axum::{
    routing::post,
    Router,
};

use crate::{
    app_state::AppState,
    handlers::membership_handler,
};

pub fn membership_routes() -> Router<AppState> {
    Router::new()
        .route("/", post(membership_handler::create))
}

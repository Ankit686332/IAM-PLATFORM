use sqlx::PgPool;

pub struct MembershipRepository;

impl MembershipRepository {
    pub async fn create(
        pool: &PgPool,
        user_id: uuid::Uuid,
        organization_id: uuid::Uuid,
    ) -> Result<(), sqlx::Error> {
        sqlx::query(
            "
            INSERT INTO memberships
            (user_id, organization_id)
            VALUES
            ($1, $2)
            ",
        )
        .bind(user_id)
        .bind(organization_id)
        .execute(pool)
        .await?;

        Ok(())
    }
}
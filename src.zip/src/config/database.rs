use sqlx::{postgres::PgPoolOptions, PgPool};

pub async fn connect(database_url: &str) -> Result<PgPool, sqlx::Error> {
    println!("DATABASE_URL = {}", database_url);

    PgPoolOptions::new()
        .max_connections(5)
        .connect(database_url)
        .await
}